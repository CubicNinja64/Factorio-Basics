require("prototypes.item.item-groups")
require("prototypes.item.items")

require("prototypes.recipe.recipes")

require("prototypes.technology.technology")